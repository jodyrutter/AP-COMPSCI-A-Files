package com.eimacs.lab08;

/**
 * Card.java
 *
 * <code>Card</code> represents a playing card.
 *
 * @author |Your name|
 * @version 1.0 |Today's date|
 */
public class Card
{

}
