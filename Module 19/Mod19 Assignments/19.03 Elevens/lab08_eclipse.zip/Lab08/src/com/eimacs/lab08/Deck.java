package com.eimacs.lab08;

import java.util.ArrayList;

/**
 * The Deck class represents a shuffled deck of cards. It provides several
 * operations including initialize, shuffle, deal, and check if empty.
 *
 * @author |Your name|
 * @version 1.0 |Today's date|
 */
public class Deck
{

}
